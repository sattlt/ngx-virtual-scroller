
export interface ViewCollection {
  fromIdx: number;
  length: number;
  collection: Array<any>;
}
