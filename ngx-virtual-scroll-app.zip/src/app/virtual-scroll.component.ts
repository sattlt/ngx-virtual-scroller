// tslint:disable-next-line:max-line-length
import { Component, OnInit, OnChanges, SimpleChanges, Input, EventEmitter, Output, Renderer2, ElementRef, NgZone, ViewChild, enableProdMode } from '@angular/core';
import { ViewCollection } from './view-collection';

const DUMMY = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];

@Component({
  // tslint:disable-next-line:component-selector
  selector: '[virtualScrollFor]',
  template: `
    <div #vcPadding class="virtual-scroll-padding"></div>
    <div #vcContent class="virtual-scroll-content"><ng-content></ng-content></div>
  `,
  styleUrls: ['./virtual-scroll.component.scss']
})
export class VirtualScrollComponent implements OnChanges {

  @Input() virtualScrollFor: Array<any> = [];
  @Input() itemHeight: number;
  @Output() viewChanged = new EventEmitter<ViewCollection>();
  @ViewChild('vcContent', { read: ElementRef }) private _contentRef: ElementRef;
  @ViewChild('vcPadding', { read: ElementRef }) private _paddingRef: ElementRef;

  private _containerHeight: number;
  private _paddingHeight: number;


  constructor(
    private _containerRef: ElementRef,
    private _renderer: Renderer2,
    private _ngZone: NgZone
  ) { }

  ngOnChanges(changes: SimpleChanges): void {
    console.log('OnChange');
    // Measurements
    this.calculateDimensions();

    this._ngZone.runOutsideAngular(() => {
      this._renderer.listen(this._containerRef.nativeElement, 'scroll', (e) => this.onScroll(e));
    });

    this.refresh();
    this.calculateOffset(0);
  }


  private onScroll(event: Event) {
    const scrollTop = event.srcElement.scrollTop;
    this.calculateOffset(scrollTop);
  }

  private calculateOffset(scrollTop: number) {
    const itemModulo = scrollTop % this.itemHeight;
    const translateY = scrollTop - itemModulo;
    const start = Math.ceil(scrollTop / this.itemHeight);

    const lst = DUMMY.map((item, idx) => {
      console.log('Item: ', start, idx, (start + idx));
      return 'Item: ' + (start + idx);
    });

    this._renderer.setStyle(this._contentRef.nativeElement, 'transform', `translateY(${translateY}px)`);

    console.log('Fire: ', start, lst);
    this.viewChanged.emit({
      // collection: ['blue', 'indigo', 'red', 'green', 'magenta', 'purple', 'orange', 'yellow', 'brown', 'black'],
      collection: lst,
      fromIdx: 0,
      length: 10
    });

  }

  private refresh() {

    this._ngZone.runOutsideAngular(() => {
      requestAnimationFrame(() => this.calculateItems());
    });
  }

  private calculateItems() {
    const container = this._containerRef.nativeElement;
    const dimensions = this.calculateDimensions();


    this._renderer.setStyle(this._paddingRef.nativeElement, 'height', `${dimensions.paddingHeight}px`);
    console.log('Mesurements', dimensions);
  }

  private calculateDimensions() {
    const container = this._containerRef.nativeElement;

    this._containerHeight = (container as Element).clientHeight;
    const paddingHeight = this.itemHeight * this.virtualScrollFor.length;

    return {
      _containerHeight: this._containerHeight,
      paddingHeight
    };
  }

}
