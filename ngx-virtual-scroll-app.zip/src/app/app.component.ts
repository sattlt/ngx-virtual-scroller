import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'app';
  virtualScrollItems = [];

  ngOnInit() {
    this.virtualScrollItems = [];

    // tslint:disable-next-line:max-line-length
    const names = ['Alfred', 'Martha', 'David', 'Donald', 'Hawkeye', 'Bruce', 'Peter', 'Christian', 'Nick', 'Stan', 'Tim', 'Paul', 'Faran', 'Leslie'];

    // tslint:disable-next-line:max-line-length
    const lastNames = ['Stark', 'Howard', 'Bridges', 'Stane', 'Paltrow', 'Potts', 'Everhart', 'Gregg', 'Guinee', 'Allen', 'Noel', 'Parker', 'Banner'];

    for (let i = 0; i < 1000; i++) {
      this.virtualScrollItems.push(
        i + this.getRandom(names)
        // {
        //   firstName: this.getRandom(names),
        //   lastName: this.getRandom(lastNames)
        // }
      );
    }
  }

  getRandom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }
}
