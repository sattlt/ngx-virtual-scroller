import { VirtualScrollDirective } from './virtual-scroll.directive';

describe('VirtualScrollDirective', () => {
  it('should create an instance', () => {
    const directive = new VirtualScrollDirective();
    expect(directive).toBeTruthy();
  });
});
