/*
 * Public API Surface of virtual-scroll
 */

export * from './lib/virtual-scroll.directive';
export * from './lib/virtual-scroll.module';
